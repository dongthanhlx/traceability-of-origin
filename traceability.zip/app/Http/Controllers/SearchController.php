<?php

namespace App\Http\Controllers;

class SearchController
{
    public function __invoke()
    {

    }
}
